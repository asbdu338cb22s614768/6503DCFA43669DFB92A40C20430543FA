# write a program that determine whether a year entered by the user is leap year or not using ifelif- else statement

def is leapyear(year)
if(year%4==0 and year%100!=0)or year%400==0:
else:
  return type
else:
return False
year=int(input("Enter a year:"))
if isleapyear('{} is a leap year', formt(year))
else:
  print('{} is not a loop year'format(yeae))